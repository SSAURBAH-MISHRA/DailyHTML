package com.capgemini.util;

import java.util.HashMap;

import com.capgemini.beans.Trainer;

public class DBUtil {
	static HashMap<Integer,Trainer> feedbackList=new HashMap<>();
	public static int generateID()
	{
		return (int) (Math.random()*1000);
	}
}
