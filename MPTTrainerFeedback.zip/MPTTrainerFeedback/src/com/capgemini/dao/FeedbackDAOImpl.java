package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.util.DBUtil;

public class FeedbackDAOImpl implements FeedbackDAO {

	HashMap<Integer,Trainer> TrainerList=new HashMap<>();
	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		TrainerList.put(DBUtil.generateID(), trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatchedException {
		// TODO Auto-generated method stub
		for(Entry<Integer,Trainer> entry:TrainerList.entrySet())
		{
			if(rating==entry.getValue().getRating())
			{
				return TrainerList;
			}
			else
			{
				throw new RatingNotMatchedException();
			}
		}
		return null;
	}

}
