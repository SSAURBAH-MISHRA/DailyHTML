package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;
import com.capgemini.exception.RatingNotMatchedException;

public class FeedbackServiceImpl implements FeedbackService {

	FeedbackDAO dao=new FeedbackDAOImpl();
	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		dao.addFeedback(trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatchedException {
		// TODO Auto-generated method stub
		return dao.getTrainerList(rating);
	}

}
