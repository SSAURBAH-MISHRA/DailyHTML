package com.capgemini.exception;

@SuppressWarnings("serial")
public class RatingNotMatchedException extends Exception {

}
