package com.capgemini.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class JunitTest {
	public static FeedbackService fservice=new FeedbackServiceImpl();

	@Before
	public void setUp() throws Exception {
	}
	
	@Test(expected=com.capgemini.exception.RatingNotMatchedException.class)
	public void test1() throws RatingNotMatchedException
	{
		fservice.addFeedback(new Trainer( "name", "courseName", LocalDate.parse("2010-11-12") , LocalDate.parse("2012-12-30"), 5));
		fservice.getTrainerList(4);
	}

}
