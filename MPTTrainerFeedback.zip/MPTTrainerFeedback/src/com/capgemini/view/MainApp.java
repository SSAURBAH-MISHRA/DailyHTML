package com.capgemini.view;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class MainApp {
	public static FeedbackService fservice=new FeedbackServiceImpl();
	public static Scanner sc=new Scanner(System.in);
public static void main(String[] args) throws RatingNotMatchedException {
	

		
		System.out.println("Enter the name: ");
		String name=sc.next();
		System.out.println("Enter the Course name: ");
		String courseName=sc.next();
		System.out.println("Enter the Start date, in YYYY-MM-DD format: ");
		String sDate=sc.next();
		LocalDate StartDate=LocalDate.parse(sDate);
//		System.out.println("Year: ");
//		int year=sc.nextInt();
//		System.out.println("Month: ");
//		int month=sc.nextInt();
//		System.out.println("Day: ");
//		int dayOfMonth=sc.nextInt();
//		LocalDate startDate=LocalDate.of(year, month, dayOfMonth);
		
		System.out.println("Enter the end date, in YYYY-MM-DD format: ");
		String eDate=sc.next();
		LocalDate EndDate=LocalDate.parse(eDate);
//		System.out.println("Year: ");
//		int eyear=sc.nextInt();
//		System.out.println("Month: ");
//		int emonth=sc.nextInt();
//		System.out.println("Day: ");
//		int edayOfMonth=sc.nextInt();
//		LocalDate endDate=LocalDate.of(eyear, emonth, edayOfMonth);
		
		System.out.println("Enter the Rating: ");
		int rating=sc.nextInt();
		
		Trainer trainer=new Trainer(name, courseName, StartDate, EndDate, rating);
		
		fservice.addFeedback(trainer);
		System.out.println("Enter that rating, you want to search the trainer accordingly: ");
		int rating1=sc.nextInt();
		System.out.println(fservice.getTrainerList(rating1));
		
	}
	
}
