<html>
<title> Addtition of 2 NO.</title>
<body> 
<p id="add"></p>
<script>
var x=10;
var y=20;
var z=x+y;
document.getElementId("add").innerHtml="Value of z is"+z;

</script>

</body>
</html>